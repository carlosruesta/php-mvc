<?php

use Alura\Cursos\Controller\FormularioInsercao;

return [
    '/novo-curso' => FormularioInsercao::class,
];
